//
//  ChoosedCellForPass.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 24.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class ChoosedCellForPass: UITableViewCell {

    @IBOutlet weak var thumbnailImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!

}
