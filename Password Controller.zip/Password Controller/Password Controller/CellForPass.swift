//
//  CellForPass.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 23.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class CellForPass: UITableViewCell {

    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelPassword: UILabel!
    @IBOutlet weak var thumbnailImage: UIImageView!
    
    var indexPath = IndexPath()

    var name: String {
        set {
            labelName.text = newValue
        }
        get {
            return labelName.text ?? "NO_NAME"
        }
    }
    
    var password: String {
        set {
            labelPassword.text = newValue
        }
        get {
            return labelPassword.text ?? "NO_PASSWORD"
        }
    }
    
    var thumbImage: UIImage {
        set {
            thumbnailImage.image = newValue
        }
        get {
            return thumbnailImage.image!
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        thumbnailImage.layer.cornerRadius = thumbnailImage.frame.width / 2
        thumbnailImage.clipsToBounds = true
    }
}
