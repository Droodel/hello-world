//
//  SettingsVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 03.08.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class SettingsVC: UIViewController {
    let CHANGE_PASSWORD = "Сменить пароль"
    let TOUCH_ID = "Touch ID"
    let ABOUT_US = "О нас"

    @IBOutlet weak var tableView: UITableView!
    
    var settings = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        settings.append(CHANGE_PASSWORD)
        settings.append(TOUCH_ID)
        settings.append(ABOUT_US)
    
    }
}
extension SettingsVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.settings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let setting = self.settings[indexPath.row]
        
        cell.textLabel?.text = setting
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(44)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cellText = tableView.cellForRow(at: indexPath)?.textLabel?.text {
            switch cellText {
            case CHANGE_PASSWORD:
                tableView.deselectRow(at: indexPath, animated: true)
                self.performSegue(withIdentifier: "toChangePassVC", sender: self)
                break
            case TOUCH_ID:
                tableView.deselectRow(at: indexPath, animated: true)
                break
            case ABOUT_US:
                tableView.deselectRow(at: indexPath, animated: true)
                self.performSegue(withIdentifier: "toAboutUsVC", sender: self)
                break
            default:
                break
            }
        }
    }
}
