//
//  ConfirmNewPasswordVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 16.08.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit
import Locksmith

class ConfirmNewPasswordVC: UIViewController {

    @IBOutlet weak var passwordTF: TextFieldBoosted!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        passwordTF.becomeFirstResponder()
    }
    
    @IBAction func ChangePassTapped(_ sender: UIBarButtonItem) {
        guard passwordTF.text != "", passwordTF.text?.characters.count == 4 else {
            passwordTF.errorCatched()
            return
        }
        
        do {
            try Locksmith.updateData(data: ["password": passwordTF.text!], forUserAccount: "passwordCell")
        } catch {
            print("ERROR TO SAVE NEW PASSWORD")
        }
        navigationController?.popToRootViewController(animated: true)
    }
}
