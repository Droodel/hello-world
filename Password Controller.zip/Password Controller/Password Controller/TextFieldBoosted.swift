//
//  TextFieldBoosted.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 26.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class TextFieldBoosted: UITextField {
    
    func errorCatched() {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.05
        animation.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 4, y: self.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 4, y: self.center.y))
        animation.autoreverses = true
        animation.repeatCount = 3
        
        self.layer.add(animation, forKey: "position")
        self.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 0.1466984161)
        self.layer.cornerRadius = 5
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.red.cgColor
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        UIView.animate(withDuration: 0.3) {
            self.backgroundColor = UIColor.white
            self.layer.borderColor = UIColor.clear.cgColor
        }
    }
}
