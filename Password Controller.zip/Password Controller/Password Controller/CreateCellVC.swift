//
//  CreateCellVCViewController.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 23.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

protocol PassDelegate {
    func didPassCreated(password: Password)
}
class CreateCellVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var avatarView: UIView!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var nameTextField: TextFieldBoosted!
    @IBOutlet weak var passwordTextField: TextFieldBoosted!
    @IBOutlet weak var heightConstraintForPlusButton: NSLayoutConstraint!
    
    @IBAction func ScreenTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    var delegate: PassDelegate?
    
    let picker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        avatarView.layer.cornerRadius = avatarView.frame.width / 2
        
        NotificationCenter.default.addObserver(self, selector: #selector (keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        self.nameTextField.delegate = self
        self.passwordTextField.delegate = self
        picker.delegate = self
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if (self.view.frame.maxY - keyboardSize.height) < self.passwordTextField.frame.maxY {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if (self.view.frame.maxY - keyboardSize.height) < self.passwordTextField.frame.maxY {
                self.view.frame.origin.y += keyboardSize.height
            }
        }
    }
    
    @IBAction func createTapped(_ sender: UIButton) {
        guard nameTextField.text != "", passwordTextField.text != "" else {
            nameTextField.errorCatched()
            passwordTextField.errorCatched()
            return
        }
        self.delegate?.didPassCreated(password: Password(name: self.nameTextField.text!, password: self.passwordTextField.text!, image: self.avatar.image!))
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func backTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func plusPhotoTapped(_ sender: UIButton) {
        let photoActionsController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Камера", style: .default) { (action) in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        let libraryAction = UIAlertAction(title: "Фотоальбом", style: .default) { (action) in
            self.picker.allowsEditing = false
            self.picker.sourceType = .photoLibrary
            self.picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
            self.picker.modalPresentationStyle = .popover
            self.present(self.picker, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
        }
        
        photoActionsController.addAction(cameraAction)
        photoActionsController.addAction(libraryAction)
        photoActionsController.addAction(cancelAction)
        
        self.present(photoActionsController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        self.avatar.image = chosenImage
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
