//
//  PasscodeVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 30.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit
import Locksmith

enum Status {
    case enter
    case create
    case change
}

class PasscodeVC: UIViewController {

    @IBOutlet weak var emptyDotFirst: UIView!
    @IBOutlet weak var emptyDotSecond: UIView!
    @IBOutlet weak var emptyDotThird: UIView!
    @IBOutlet weak var emptyDotFourth: UIView!
    
    @IBOutlet weak var number1: UIButton!
    @IBOutlet weak var number2: UIButton!
    @IBOutlet weak var number3: UIButton!
    @IBOutlet weak var number4: UIButton!
    @IBOutlet weak var number5: UIButton!
    @IBOutlet weak var number6: UIButton!
    @IBOutlet weak var number7: UIButton!
    @IBOutlet weak var number8: UIButton!
    @IBOutlet weak var number9: UIButton!
    @IBOutlet weak var number0: UIButton!
    
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    
    var appWasOpened = false
    var status: Status = .enter
    
    var position: Int = 0 {
        didSet{
            switch position {
            case 0:
                emptyDotFirst.backgroundColor = UIColor.clear
            case 1:
                emptyDotFirst.backgroundColor = numberBorderColor
                emptyDotSecond.backgroundColor = UIColor.clear
                emptyDotThird.backgroundColor = UIColor.clear
                emptyDotFourth.backgroundColor = UIColor.clear
                break
            case 2:
                emptyDotSecond.backgroundColor = numberBorderColor
                emptyDotThird.backgroundColor = UIColor.clear
                emptyDotFourth.backgroundColor = UIColor.clear
                break
            case 3:
                emptyDotThird.backgroundColor = numberBorderColor
                emptyDotFourth.backgroundColor = UIColor.clear
                break
            case 4:
                emptyDotFourth.backgroundColor = numberBorderColor
                checkPassword()
                break
            default:
                break
            }
        }
    }

    let numberBorderColor = #colorLiteral(red: 0, green: 0.6158116514, blue: 1, alpha: 1)
    
    var password = ""
    var neededPassword: String {
        set{
            do {
                try Locksmith.saveData(data: ["password": newValue], forUserAccount: "passwordCell")
            } catch {
                print("Can't save data to KEYCHAIN")
            }
        }
        get{
            let data = Locksmith.loadDataForUserAccount(userAccount: "passwordCell")
            return data?["password"] as? String ?? ""
        }
    }
    
    @IBAction func numberTouchedUpInside(_ sender: UIButton) {
        let buttonNumber = sender.titleLabel!.text!
        sender.backgroundColor = UIColor.clear
        
        password += "\(buttonNumber)"
        position += 1
        
    }
    @IBAction func numberSelected(_ sender: UIButton) {
        sender.backgroundColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
    }
    
    func checkPassword() {
        if status == .create {
            neededPassword = password
            self.dismiss(animated: true, completion: nil)
        } else if status == .enter {
            if password == neededPassword {
                self.dismiss(animated: true, completion: nil)
            } else {
                emptyDotFirst.backgroundColor = UIColor.clear
                emptyDotSecond.backgroundColor = UIColor.clear
                emptyDotThird.backgroundColor = UIColor.clear
                emptyDotFourth.backgroundColor = UIColor.clear
                password = ""
                position = 0
                return
            }
        } else if status == .change {
            if password == neededPassword {
                emptyDotFirst.backgroundColor = UIColor.clear
                emptyDotSecond.backgroundColor = UIColor.clear
                emptyDotThird.backgroundColor = UIColor.clear
                emptyDotFourth.backgroundColor = UIColor.clear
                password = ""
                position = 0
                
                topLabel.text = "Введите новый пароль"
                
            } else {
                emptyDotFirst.backgroundColor = UIColor.clear
                emptyDotSecond.backgroundColor = UIColor.clear
                emptyDotThird.backgroundColor = UIColor.clear
                emptyDotFourth.backgroundColor = UIColor.clear
                password = ""
                position = 0
                return
            }
        }
    }

    @IBAction func deleteTapped(_ sender: UIButton) {
        if position > 0 {
            position -= 1
            password.remove(at: password.index(before: password.endIndex))
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if !appWasOpened {
            self.topLabel.text = "Создайте пароль"
        } else {
            self.topLabel.text = "Введите пароль"
        }
        position = 0
        configureButtons()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        initLabel()
    }
    
    func initLabel() {
        if status == .enter {
            self.topLabel.text = "Введите пароль"
        } else if status == .create {
            self.topLabel.text = "Создайте пароль"
        } else {
            self.topLabel.text = "Введите старый пароль"
        }
    }
    
    func configureButtons() {
        number1.layer.cornerRadius = number1.frame.width / 2
        number2.layer.cornerRadius = number1.frame.width / 2
        number3.layer.cornerRadius = number1.frame.width / 2
        number4.layer.cornerRadius = number1.frame.width / 2
        number5.layer.cornerRadius = number1.frame.width / 2
        number6.layer.cornerRadius = number1.frame.width / 2
        number7.layer.cornerRadius = number1.frame.width / 2
        number8.layer.cornerRadius = number1.frame.width / 2
        number9.layer.cornerRadius = number1.frame.width / 2
        number0.layer.cornerRadius = number1.frame.width / 2
        
        emptyDotFirst.layer.cornerRadius = emptyDotFirst.frame.width / 2
        emptyDotSecond.layer.cornerRadius = emptyDotFirst.frame.width / 2
        emptyDotThird.layer.cornerRadius = emptyDotFirst.frame.width / 2
        emptyDotFourth.layer.cornerRadius = emptyDotFirst.frame.width / 2
        
        emptyDotFirst.layer.borderWidth = 1
        emptyDotFirst.layer.borderColor = numberBorderColor.cgColor
        emptyDotSecond.layer.borderWidth = 1
        emptyDotSecond.layer.borderColor = numberBorderColor.cgColor
        emptyDotThird.layer.borderWidth = 1
        emptyDotThird.layer.borderColor = numberBorderColor.cgColor
        emptyDotFourth.layer.borderWidth = 1
        emptyDotFourth.layer.borderColor = numberBorderColor.cgColor
        
        number1.layer.borderWidth = 1
        number2.layer.borderWidth = 1
        number3.layer.borderWidth = 1
        number4.layer.borderWidth = 1
        number5.layer.borderWidth = 1
        number6.layer.borderWidth = 1
        number7.layer.borderWidth = 1
        number8.layer.borderWidth = 1
        number9.layer.borderWidth = 1
        number0.layer.borderWidth = 1
        
        number1.layer.borderColor = numberBorderColor.cgColor
        number2.layer.borderColor = numberBorderColor.cgColor
        number3.layer.borderColor = numberBorderColor.cgColor
        number4.layer.borderColor = numberBorderColor.cgColor
        number5.layer.borderColor = numberBorderColor.cgColor
        number6.layer.borderColor = numberBorderColor.cgColor
        number7.layer.borderColor = numberBorderColor.cgColor
        number8.layer.borderColor = numberBorderColor.cgColor
        number9.layer.borderColor = numberBorderColor.cgColor
        number0.layer.borderColor = numberBorderColor.cgColor
    }
}

