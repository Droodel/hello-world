//
//  Password.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 27.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class Password: NSObject, NSCoding {
    var name = ""
    var password = ""
    var image = UIImage(named: "noImage")
    
    init(name: String, password: String, image: UIImage) {
        self.name = name
        self.password = password
        self.image = image
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        self.name = aDecoder.decodeObject(forKey: "name") as! String;
        self.password = aDecoder.decodeObject(forKey: "password") as! String;
        self.image = aDecoder.decodeObject(forKey: "image") as! UIImage;
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.name, forKey: "name");
        aCoder.encode(self.password, forKey: "password");
        aCoder.encode(self.image, forKey: "image");
    }
}

