//
//  AboutUsVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 16.08.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class AboutUsVC: UIViewController {

    @IBOutlet weak var textLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        textLabel.text = "Классное приложение, простое и удобное. Донатьте пацаны, всем добра и так далее"
    }

}
