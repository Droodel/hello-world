//
//  MainVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 23.07.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit

class MainVC: UITableViewController, PassDelegate {
    var passwords = [Password]()
    var imgOpened = false
    let file = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("passwords")
    var appWasOpened: Bool {
        get{
            return UserDefaults.standard.bool(forKey: "wasOpened")
        }
        set{
            UserDefaults.standard.set(newValue, forKey: "wasOpened")
        }
    }
    @IBAction func addTapped(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "toCreateCellVC", sender: self)
    }
    
    func didPassCreated(password: Password) {
        self.passwords.append(password)
        self.tableView.reloadData()
        self.savePasswords()
    }
    
    @IBAction func settingsTapped(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "toSettingsVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toCreateCellVC" {
            let vc = segue.destination as! CreateCellVC
            vc.delegate = self
        }
        if segue.identifier == "toPasscodeVC" {
            let vc = segue.destination as! PasscodeVC
            if !appWasOpened {
                vc.status = .create
            } else {
                vc.status = .enter
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.performSegue(withIdentifier: "toPasscodeVC", sender: self)
        if !self.appWasOpened {
            passwords.append(Password(name: "Зажмите картику слева, чтобы приблизить", password: "Дерните влево ячейку, чтобы удалить ее", image: UIImage(named: "noImage")!))
            self.appWasOpened = true
        }
        loadPasswords()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        savePasswords()
    }
    
    func savePasswords() {
        NSKeyedArchiver.archiveRootObject(self.passwords, toFile: self.file.path)
    }
    
    func loadPasswords() {
        if let passes = NSKeyedUnarchiver.unarchiveObject(withFile: self.file.path) as? [Password] {
            self.passwords = passes
        }
    }
    
    func thumbnailImageHandler(_ sender: UILongPressGestureRecognizer) {
        let thumbnailImage = sender.view!
        let cell = sender.view?.superview?.superview as? CellForPass
        
        let xForScale = (self.view.frame.width - thumbnailImage.frame.width / 3) / thumbnailImage.frame.width
        let yForScale = (self.view.frame.height - 80) / thumbnailImage.frame.height
        
        let xForTranslating = (self.view.frame.width / 2) - (thumbnailImage.frame.width / 2) - 9.5
        let yForTranslating: CGFloat = self.view.frame.maxY - (cell!.center.y + yForScale * thumbnailImage.frame.height / 2) - 74
        
        let scaleTransform = CGAffineTransform(scaleX: xForScale, y: yForScale)
        let translateTransform = CGAffineTransform(translationX: xForTranslating, y: yForTranslating)
        let transform = scaleTransform.concatenating(translateTransform)
        if sender.state == UIGestureRecognizerState.began {
            UIView.animate(withDuration: 0.05, animations : {
                thumbnailImage.layer.cornerRadius = 0
                self.view.insertSubview(cell!, aboveSubview: self.view)
                thumbnailImage.transform = transform
            })
        }
        if sender.state == UIGestureRecognizerState.ended {
            UIView.animate(withDuration: 0.05, animations: { 
                thumbnailImage.layer.cornerRadius = 28
                self.view.insertSubview(cell!, belowSubview: self.view)
                thumbnailImage.transform = .identity
            }, completion: { _ in
                self.tableView.reloadData()
            })
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return passwords.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CellForPass
        
        cell.clipsToBounds = false
        cell.thumbnailImage.clipsToBounds = true
        cell.indexPath = indexPath
        cell.selectionStyle = .none
        let pass = passwords[indexPath.row]
        cell.name = pass.name
        cell.password = pass.password
        cell.thumbnailImage.image = pass.image
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(thumbnailImageHandler))
        longPressRecognizer.minimumPressDuration = 0.3
        longPressRecognizer.numberOfTouchesRequired = 1
        cell.thumbnailImage.addGestureRecognizer(longPressRecognizer)
        
        return cell
    }
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .default, title: "Удалить") { (action, indexPath) in
            self.passwords.remove(at: indexPath.row)
            self.tableView.reloadData()
            self.savePasswords()
        }
        delete.backgroundColor = UIColor.red
        
        return [delete]
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}













