//
//  ChangePassVC.swift
//  Password Controller
//
//  Created by Евгений Сивицкий on 07.08.17.
//  Copyright © 2017 Евгений Сивицкий. All rights reserved.
//

import UIKit
import Locksmith

class ChangePassVC: UIViewController {
    
    private let oldPassword = Locksmith.loadDataForUserAccount(userAccount: "passwordCell")
    @IBOutlet weak var changePassTF: TextFieldBoosted!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        changePassTF.becomeFirstResponder()
    }
    
    @IBAction func nextTapped(_ sender: UIBarButtonItem) {
        if let oldPass = oldPassword {
            if changePassTF.text == oldPass["password"] as? String {
                self.performSegue(withIdentifier: "toConfirmPassVC", sender: self)
            } else {
                changePassTF.errorCatched()
            }
        }
    }
}
